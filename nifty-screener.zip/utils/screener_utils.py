import pandas as pd

def filter_stocks(rsi_min, rsi_max, volume_x, price_above_ema):
    df = pd.read_csv("data/sample.csv")
    df = df[
        (df["RSI"] >= rsi_min) &
        (df["RSI"] <= rsi_max) &
        (df["Volume"] > df["AvgVolume"] * volume_x)
    ]

    if price_above_ema == "20 EMA":
        df = df[df["Price"] > df["EMA20"]]
    elif price_above_ema == "50 EMA":
        df = df[df["Price"] > df["EMA50"]]
    elif price_above_ema == "Both":
        df = df[(df["Price"] > df["EMA20"]) & (df["Price"] > df["EMA50"])]
    return df
