import streamlit as st
import pandas as pd
from utils.screener_utils import filter_stocks

st.set_page_config(page_title="Nifty Screener", layout="wide")
st.title("📈 Nifty Sector Stock Screener")

rsi_min = st.slider("RSI Min", 0, 100, 30)
rsi_max = st.slider("RSI Max", 0, 100, 70)
volume_x = st.selectbox("Volume Spike >", [1.5, 2, 3])
price_above_ema = st.selectbox("Price Above EMA", ["20 EMA", "50 EMA", "Both"])

filtered_df = filter_stocks(rsi_min, rsi_max, volume_x, price_above_ema)

st.write(f"🎯 {len(filtered_df)} stocks matched your criteria")
st.dataframe(filtered_df)

st.download_button("📥 Download CSV", filtered_df.to_csv(index=False), "filtered_stocks.csv")

st.subheader("📊 Charts")
for _, row in filtered_df.iterrows():
    symbol = row['symbol']
    tv_url = f"https://www.tradingview.com/chart/?symbol=NSE:{symbol}"
    st.markdown(f"[{symbol} Chart]({tv_url})", unsafe_allow_html=True)
